-- REA Implements – Helfer Traktion Patch 1.0.5
REAimplements = {}
REAimplements.HelperForce = 1.8
